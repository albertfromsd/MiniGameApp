const ChatroomController = require('../controllers/Chatroom.controller');

module.exports = function(app) {

}