import React, { useState, useEffect } from 'react';
import io from 'socket.io-client';
import { Link, Router, Redirect } from '@reach/router';

import NavBar from './components/NavBar';
import LoginReg from './views/LoginReg';
import Lobby from './views/Lobby';
import Chatroom from './views/Chatroom';
import HumanCalculator from './components/games/HumanCalculator';

import './MainApp.css';

function MainApp() {

  return (
    <>
    <Router>
      <LoginReg path="/" />
      <Lobby path="/lobby" />
      <Chatroom path="/chatroom/:roomName" />
      <HumanCalculator path="/games/humancalculator" />
    </Router>
    </>
  );
}

export default MainApp;
