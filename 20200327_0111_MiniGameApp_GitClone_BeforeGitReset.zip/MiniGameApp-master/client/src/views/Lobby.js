import React, { useState, useEffect } from 'react';
import axios from 'axios';
import io from 'socket.io-client';
import { Link, Router, navigate } from '@reach/router';

import NavBar from '../components/NavBar';
import HumanCalculator from '../components/games/HumanCalculator';
import LogoutButton from '../components/loginreg/LogoutButton'

import styles from './Lobby.module.css';

const Lobby = () => {
    const [ socket ] = useState( () => io(':8000') );
    const [ user, setUser ] = useState("")

    useEffect( () => {
        // axios.get("/api/user/id/"+userid)
        //     .then(res => setUser(res.data))
        //     .catch(console.log);

        socket.on('welcome', data => {
            console.log(data);
        });
        return () => {
            socket.disconnect();
        }
    }, [socket]);

    const gameSelector = e => {
        navigate('/games/'+e.target.value);
    };

    return (
        <>
        <NavBar />
            <br/>
        <div className={styles.entirePage}>
            <h2>Game Room Lobby</h2>
                <br/>
            <h3>Pick a game below:</h3>
                <br/>
            <button onClick={gameSelector} name="gamebutton" value="humancalculator">Human Calculator</button>{" "}

        </div>
        <Router>
            <HumanCalculator path="/games/humancalculator" socket={socket}/>
        </Router>

        </>
    );
};

export default Lobby;