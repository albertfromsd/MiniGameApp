import React, { useState } from 'react';

import styles from './HumanCalculator.module.css';

const HumanCalculator = ({ socket }) => {
    // FORM VISIBILITY
    const [ formVisibility, setFormVisibility ] = useState("hidden");

    // CREATING QUESTION AND ANSWER
    const [ difficulty, setDifficulty ] = useState("Easy");
    const [ question, setQuestion ] = useState();
    const [ answer, setAnswer ] = useState();

    // POST ANSWER SUBMISSION
    const [ formAnswer, setFormAnswer ] = useState("");
    const [ resultMsg, setResultMsg ] = useState([]);
    const [ resultColor, setResultColor ] = useState("");

    // ANSWER TIMER
    const [ qCreatedAt, setQCreatedAt ] = useState("");
    const [ qAnsweredAt, setQAnsweredAt ] = useState("");
    const [ timeToAnswer, setTimeToAnswer ] = useState("");

    const changeDifficulty = e => {
        setDifficulty(e.target.value);
    }


    const createQuestion = e => {
        // Start timer
        console.log("-----------------")
        setQCreatedAt( new Date().getTime() );

        setResultMsg([]);
        setFormVisibility("visible");

        const getRandomInt = (maxNum, minNum) => {
            let num = Math.floor(Math.random() * (maxNum - minNum) + minNum );
            return num;
        }

        const generateOperands = (max, min) => {
            const num1 = getRandomInt(max, min);
            const num2 = getRandomInt(max, min);
            let result = (num1*num2);
            setQuestion(num1 + " × " + num2);
            setAnswer(result);
        } 

        // SET DIFFCULTY
        // how to access max/min values outside of scope of if statements
        let max;
        let min;
        if (difficulty == "Easy") {
            max = 15;
            min = 2;
        }
        if (difficulty == "Medium") {
            max = 50;
            min = 3;
        }
        if (difficulty == "Hard") {
            max = 100;
            min = 11;
        }
        if (difficulty == "Genius") {
            max = 1000;
            min = 101;
        } 
        generateOperands(max, min);
    }

    const submitAnswer = e => {
        e.preventDefault();
        if (formAnswer == answer ) {

            setQAnsweredAt( new Date().getTime() );
            let timeDiff = ( (qAnsweredAt - qCreatedAt )/1000000000000 );
            setTimeToAnswer( timeDiff );

            setResultMsg(["Correct!",question+" does equal "+formAnswer+"!", "You got it in: "+timeDiff+" seconds."]);
            setResultColor("green");

            // [TOP] Timer calculation not working

            setFormVisibility("hidden");
            console.log("[ ALL TOGETHER NOW ]");
            console.log("Created at: "+qCreatedAt);
            console.log("Answered at: "+qAnsweredAt);
            console.log("Time to answer: "+timeToAnswer);
            // [END] Timer calculation not working

        } else {
            setResultMsg(["WROOONG!", question + " does not equal "+formAnswer+"!"]);
            setResultColor("red");
        }
        setFormAnswer("");

    }

    // [STYLING]
    let hiddenForm = {
        display: "none"
    }
    let visibleForm = {
        display: "flex",
        flexFlow: "column",
        justifyContent: "center",
        alignItems: "center"
    }

    // [BUTTONS]
    const difficultyLevels = ["Easy", "Medium", "Hard", "Genius"]

    return(
        <div className={styles.entirePage}>
            <h2>Human Calculator</h2>
            <br/>
            <div>
                {difficultyLevels.map( (d, i) => {
                    let buttonStyle = (d == difficulty ? styles.activeBtn : styles.inactiveBtn );

                    return (
                        <button 
                            onClick={changeDifficulty} 
                            key={i} 
                            name={d} 
                            value={d} 
                            className={styles.btn, buttonStyle}>
                                {d}
                        </button>
                    )

                })}
            </div>
            <br/>
            <button onClick={createQuestion} className={styles.createBtn}>{"Create " + difficulty + " Problem"}</button>
            <br/>

                {resultMsg.length > 0 && resultMsg.map( (msg, i) => 
                    <>
                    <p style={{color: resultColor}} key={i}>{msg}</p>
                        <br/>
                    </>
                )}
                
            <br/>
            <div style={formVisibility == "hidden" 
                ? hiddenForm 
                : visibleForm}>
                <p>{question}</p>
                    <br/>
                    <br/>
                    <br/>
                <form onSubmit={submitAnswer}>
                    <input 
                        type="text"
                        placeholder="Enter you answer here"
                        value={formAnswer}
                        onChange={e=>setFormAnswer(e.target.value)}/>
                    <input type="submit" value="Submit your answer"/>
                </form>
            </div>
        </div>
    )
};

export default HumanCalculator;