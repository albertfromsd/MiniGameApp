"# MiniGameApp" 

Dependencies:

[SERVER]
express express-session mongoose cors jsonwebtoken bcrypt dotenv cookie-parser socket.io

[CLIENT]
axios @reach/router socket.io-client redux react-redux

[ENV]
need to create your own .env inside /server folder
