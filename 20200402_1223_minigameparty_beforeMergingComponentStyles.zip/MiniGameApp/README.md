"# MiniGameApp" 

Dependencies:

[SERVER]
express mongoose cors jsonwebtoken bcrypt dotenv cookie-parser socket.io express-session

[CLIENT]
axios @reach/router socket.io-client redux react-redux
random-words react-reveal material-ui @material-ui/core


[ENV]
need to create your own .env inside /server folder
