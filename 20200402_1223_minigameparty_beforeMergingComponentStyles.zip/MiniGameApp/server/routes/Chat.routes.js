const ChatCtrl = require('../controllers/Chat.controller');

module.exports = function(app) {

}